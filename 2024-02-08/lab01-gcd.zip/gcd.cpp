#include "gcd.hpp"

int gcd_instructor(int m, int n)
{
  if (m == n) return m;
  if (m > n) m -= n;
  else n -= m;
  return gcd_instructor(m,n);
}

int gcd_modulus(int m, int n)
{
  if (m == 0) return n; // return last divsor if modulus is 0
  else if (n == 0) return m;
  else {
    if (m > n) m %= n;
    else n %= m;
  }
  return gcd_modulus(m,n);
}
