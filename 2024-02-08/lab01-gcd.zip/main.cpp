#include "gcd.hpp"
#include <iostream>

int main()
{
  std::cout << "GCD of 250 and 350 is "
	    << gcd_instructor(250,350)
	    << " = "
	    << gcd_modulus(250,350) << ".\n";
}
