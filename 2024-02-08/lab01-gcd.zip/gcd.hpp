// GCD algorithms
#ifndef GCD_HPP
#define GCD_HPP

int gcd_instructor(int,int);
int gcd_modulus(int,int);

#endif
